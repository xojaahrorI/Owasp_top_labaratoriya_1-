-- NestMarket production DB dump (staging snapshot)
-- Generated automatically before the v2.4 deploy - DO NOT commit to git.
-- TODO(dev): delete this file from the server after migration is verified.

CREATE TABLE users_snapshot (
  id INTEGER,
  username TEXT,
  role TEXT,
  note TEXT
);

INSERT INTO users_snapshot VALUES (1, 'admin_ops', 'admin', 'rotate creds quarterly');
INSERT INTO users_snapshot VALUES (2, 'support_helpdesk', 'support', 'shared inbox account');
-- dev note: leaked during a rushed hotfix, sorry team
-- lab-flag: FLAG{a02_leaked_backup_sql_dump_77ab}
INSERT INTO users_snapshot VALUES (3, 'j.tursunov', 'customer', NULL);
